import json
import os
import shutil
import uuid
from pathlib import Path

from fastapi import BackgroundTasks, Depends, FastAPI, File, HTTPException, UploadFile
from sqlalchemy.orm import Session

from .database import Base, SessionLocal, engine
from .models import ImageRecord
from .schemas import UploadResponse, StatusResponse, ResultResponse
from .services.image_checks import sha256_file
from .worker import process_image

app = FastAPI(
    title="Intelligent Media Processing Pipeline",
    version="1.0.0",
)

UPLOAD_DIR = Path("uploads")
UPLOAD_DIR.mkdir(exist_ok=True)

Base.metadata.create_all(bind=engine)

ALLOWED_TYPES = {"image/jpeg", "image/png", "image/webp"}
MAX_SIZE = 10 * 1024 * 1024

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@app.get("/health")
def health():
    return {"status": "ok"}

@app.post("/api/v1/images", response_model=UploadResponse)
async def upload_image(
    background_tasks: BackgroundTasks,
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
):
    if file.content_type not in ALLOWED_TYPES:
        raise HTTPException(status_code=400, detail="Unsupported image type")

    processing_id = str(uuid.uuid4())
    extension = Path(file.filename or "image.jpg").suffix.lower() or ".jpg"
    destination = UPLOAD_DIR / f"{processing_id}{extension}"

    size = 0
    with destination.open("wb") as out:
        while chunk := await file.read(1024 * 1024):
            size += len(chunk)
            if size > MAX_SIZE:
                destination.unlink(missing_ok=True)
                raise HTTPException(status_code=413, detail="Image exceeds 10 MB")
            out.write(chunk)

    try:
        digest = sha256_file(str(destination))
    except Exception:
        destination.unlink(missing_ok=True)
        raise HTTPException(status_code=400, detail="Invalid image file")

    record = ImageRecord(
        id=processing_id,
        filename=file.filename or destination.name,
        storage_path=str(destination),
        mime_type=file.content_type,
        file_size=size,
        sha256=digest,
        status="pending",
    )
    db.add(record)
    db.commit()

    # Return immediately; analysis is performed in the background.
    background_tasks.add_task(process_image, processing_id)

    return UploadResponse(processing_id=processing_id, status="pending")

@app.get("/api/v1/images/{processing_id}/status", response_model=StatusResponse)
def status(processing_id: str, db: Session = Depends(get_db)):
    record = db.get(ImageRecord, processing_id)
    if not record:
        raise HTTPException(status_code=404, detail="Processing ID not found")
    return StatusResponse(
        processing_id=record.id,
        status=record.status,
        error=record.error_message,
    )

@app.get("/api/v1/images/{processing_id}/results", response_model=ResultResponse)
def results(processing_id: str, db: Session = Depends(get_db)):
    record = db.get(ImageRecord, processing_id)
    if not record:
        raise HTTPException(status_code=404, detail="Processing ID not found")

    analysis = json.loads(record.analysis_json) if record.analysis_json else None
    return ResultResponse(
        processing_id=record.id,
        status=record.status,
        analysis=analysis,
        error=record.error_message,
    )
