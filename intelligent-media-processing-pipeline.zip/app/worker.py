import json
from datetime import datetime
from sqlalchemy.orm import Session

from .models import ImageRecord
from .services.image_checks import (
    load_image, blur_check, brightness_check, dimension_check,
    ocr_check, plate_check, basic_screenshot_heuristic
)

def process_image(record_id: str):
    from .database import SessionLocal

    db: Session = SessionLocal()
    try:
        record = db.get(ImageRecord, record_id)
        if not record:
            return

        record.status = "processing"
        record.updated_at = datetime.utcnow()
        db.commit()

        image = load_image(record.storage_path)

        ocr = ocr_check(image)
        analysis = {
            "blur": blur_check(image),
            "brightness": brightness_check(image),
            "duplicate": {"detected": False},
            "ocr": ocr,
            "number_plate": plate_check(ocr.get("text")),
            "dimensions": dimension_check(image),
            "screenshot": basic_screenshot_heuristic(image, record.storage_path),
        }

        # Exact duplicate detection against previous completed uploads.
        previous = (
            db.query(ImageRecord)
            .filter(
                ImageRecord.sha256 == record.sha256,
                ImageRecord.id != record.id
            )
            .first()
        )
        analysis["duplicate"]["detected"] = previous is not None
        if previous:
            analysis["duplicate"]["duplicate_of"] = previous.id

        record.analysis_json = json.dumps(analysis)
        record.status = "completed"
        record.updated_at = datetime.utcnow()
        db.commit()

    except Exception as exc:
        record = db.get(ImageRecord, record_id)
        if record:
            record.status = "failed"
            record.error_message = str(exc)
            record.updated_at = datetime.utcnow()
            db.commit()
    finally:
        db.close()
