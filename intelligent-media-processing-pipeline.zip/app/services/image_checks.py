import hashlib
import re
from pathlib import Path
import cv2
import numpy as np

PLATE_PATTERN = re.compile(
    r"^(?:[A-Z]{2})[- ]?[0-9]{1,2}[- ]?[A-Z]{1,3}[- ]?[0-9]{3,4}$"
)

def sha256_file(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()

def load_image(path: str):
    image = cv2.imread(path)
    if image is None:
        raise ValueError("Unable to decode image")
    return image

def blur_check(image):
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    score = float(cv2.Laplacian(gray, cv2.CV_64F).var())
    return {"detected": score < 80.0, "score": round(score, 2)}

def brightness_check(image):
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    score = float(np.mean(gray))
    return {"low_light": score < 50.0, "score": round(score, 2)}

def dimension_check(image):
    height, width = image.shape[:2]
    valid = width >= 320 and height >= 240
    return {"width": width, "height": height, "valid": valid}

def ocr_check(image):
    try:
        import pytesseract
        text = pytesseract.image_to_string(image, config="--psm 6").strip()
        cleaned = re.sub(r"[^A-Z0-9 -]", "", text.upper())
        return {"text": cleaned or None, "confidence": None}
    except Exception as exc:
        return {"text": None, "confidence": None, "available": False, "reason": str(exc)}

def plate_check(text: str | None):
    if not text:
        return {"format_valid": False, "matched_text": None}
    candidates = re.findall(r"[A-Z0-9-]{6,12}", text.upper())
    for candidate in candidates:
        normalized = candidate.replace(" ", "")
        if PLATE_PATTERN.match(normalized):
            return {"format_valid": True, "matched_text": normalized}
    return {"format_valid": False, "matched_text": None}

def basic_screenshot_heuristic(image, path: str):
    h, w = image.shape[:2]
    # A deliberately conservative heuristic: this is only a suspicion signal.
    ratio = w / h if h else 0
    suspected = ratio > 2.0 or ratio < 0.5
    return {
        "suspected": bool(suspected),
        "reason": "unusual_aspect_ratio" if suspected else None
    }
