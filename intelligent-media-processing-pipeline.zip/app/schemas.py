from typing import Any
from pydantic import BaseModel

class UploadResponse(BaseModel):
    processing_id: str
    status: str

class StatusResponse(BaseModel):
    processing_id: str
    status: str
    error: str | None = None

class ResultResponse(BaseModel):
    processing_id: str
    status: str
    analysis: dict[str, Any] | None = None
    error: str | None = None
