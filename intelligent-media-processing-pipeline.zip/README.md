# Intelligent Media Processing Pipeline

Backend + AI Engineering Take-Home Assignment solution.

## Architecture

Client -> FastAPI Upload API -> SQLite metadata -> Background Job -> Image Analysis -> Results API

The image analysis runs asynchronously using FastAPI BackgroundTasks. The implementation is intentionally small and easy to run locally while keeping the processing logic modular.

## Checks implemented

1. Blur detection using OpenCV Laplacian variance
2. Brightness / low-light detection
3. Duplicate detection using SHA-256
4. OCR extraction using Tesseract (optional if Tesseract is unavailable)
5. Indian vehicle-number format validation
6. Image dimension validation
7. Basic screenshot/photo-of-photo heuristic using metadata and image characteristics

## Status flow

pending -> processing -> completed
                     \
                      -> failed

## Project structure

app/
  main.py              API endpoints
  database.py          SQLite setup
  models.py            SQLAlchemy models
  schemas.py           Pydantic response/request models
  worker.py            asynchronous processing pipeline
  services/
    image_checks.py    image analysis functions
uploads/               uploaded images
tests/
  test_api.py
requirements.txt
Dockerfile
docker-compose.yml

## Run locally

### 1. Create environment

python -m venv .venv

Windows:
.venv\Scripts\activate

macOS/Linux:
source .venv/bin/activate

### 2. Install dependencies

pip install -r requirements.txt

### 3. Start API

uvicorn app.main:app --reload

Open:
http://127.0.0.1:8000/docs

## Docker

docker compose up --build

## API examples

### Upload

curl -X POST "http://localhost:8000/api/v1/images" \
  -F "file=@car.jpg"

Response:

{
  "processing_id": "uuid",
  "status": "pending"
}

### Status

GET /api/v1/images/{processing_id}/status

### Results

GET /api/v1/images/{processing_id}/results

## Example result

{
  "processing_id": "uuid",
  "status": "completed",
  "analysis": {
    "blur": {"detected": false, "score": 185.2},
    "brightness": {"low_light": false, "score": 124.4},
    "duplicate": {"detected": false},
    "ocr": {"text": "KA01AB1234", "confidence": null},
    "number_plate": {"format_valid": true},
    "dimensions": {"width": 1920, "height": 1080, "valid": true}
  }
}

## Design decisions

- SQLite is used for a zero-configuration local demo. PostgreSQL can replace it without changing the API design.
- BackgroundTasks keeps the 48-hour solution simple. A production deployment should use Redis + Celery/RQ or another durable queue.
- SHA-256 detects exact duplicate files. A perceptual hash would be preferable for near-duplicate images.
- Heuristics return evidence/flags rather than claiming perfect ML accuracy.
- OCR is optional: if Tesseract is not installed, the rest of the pipeline still completes.

## AI usage disclosure

AI assistance was used for architecture brainstorming, boilerplate generation, API examples, and reviewing edge cases. Generated code should be manually tested and validated before submission. Any AI-generated output that does not match the assignment requirements should be corrected rather than used blindly.

## Trade-offs and future improvements

- Replace SQLite with PostgreSQL.
- Replace BackgroundTasks with a durable queue such as BullMQ, RabbitMQ, SQS, or Celery.
- Store files in S3-compatible object storage.
- Add authentication and rate limiting.
- Add structured logging and metrics.
- Add retry/dead-letter handling.
- Add perceptual duplicate detection.
- Add a dedicated OCR/number-plate model.
- Add confidence scoring and a dashboard.
